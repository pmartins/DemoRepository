const { apiImoveis } = require("../../fixtures/imoveis/api-imoveis-fixture");

exports.funcGetApiImoveisName = (name) => 
{
      outPutMessage = {
        status: 404,
        result: { }
      };

      let imovelfound = apiImoveis.filter((imovel) => imovel.titulo.toUpperCase().indexOf(name.toUpperCase()) !== -1);

      if (imovelfound != null){
        outPutMessage.status = 200;
        outPutMessage.result = imovelfound;
      }

      return outPutMessage;
}