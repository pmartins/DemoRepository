const { apiCategorias } = require("../../fixtures/categorias/api-categorias-fixture");

exports.funcGetApiCategoriasId = (id) => 
{
      outPutMessage = {
            status: 404,
            result: {}
      };

      const categoriaFound = apiCategorias.find((categoria) => categoria.id == id);

      if (categoriaFound != null){
            outPutMessage.status = 200;
            outPutMessage.result = categoriaFound;
      }

      return outPutMessage;
}