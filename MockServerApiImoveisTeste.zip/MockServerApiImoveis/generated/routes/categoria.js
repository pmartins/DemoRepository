const { postApiCategorias, getApiCategoriasId, getApiCategoriasTitle } = require("../middleware/categorias/api-categoria-middlewares");

module.exports = [
  {
    id: "post-api-categorias", 
    url: "/api/categorias", 
    method: "POST",
    variants: [
      {
        id: "post-api-categorias", 
        type: "middleware", 
        options: { 
          middleware: postApiCategorias,
        },
      },
    ],
  },
  {
    id: "get-api-categorias-id", 
    url: "/api/categorias/:id", 
    method: "GET", 
    variants: [
      {
        id: "get-api-categorias-id", 
        type: "middleware", 
        options: {
          middleware: getApiCategoriasId,
        },
      },
    ],
  },
  {
    id: "get-api-categorias-title",
    url: "/api/categorias/title/:title",
    method: "GET",
    variants: [
      {
        id: "get-api-categorias-title", 
        type: "middleware", 
        options: {
          middleware: getApiCategoriasTitle,
        },
      },
    ],
  },
];
