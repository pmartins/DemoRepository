const { postApiImoveis, getApiImoveisId, getApiImoveisName } = require("../middleware/imoveis/api-imoveis-middleware");

module.exports = [
  {
    id: "post-api-imoveis", 
    url: "/api/imoveis", 
    method: "POST",
    variants: [
      {
        id: "post-api-imoveis", 
        type: "middleware", 
        options: { 
          middleware: postApiImoveis,
        },
      },
    ],
  },
  {
    id: "get-api-imoveis-id", 
    url: "/api/imoveis/:id", 
    method: "GET", 
    variants: [
      {
        id: "get-api-imoveis-id", 
        type: "middleware", 
        options: {
          middleware: getApiImoveisId,
        },
      },
    ],
  },
  {
    id: "get-api-imoveis-name",
    url: "/api/imoveis/name/:name",
    method: "GET",
    variants: [
      {
        id: "get-api-imoveis-name", 
        type: "middleware", 
        options: {
          middleware: getApiImoveisName,
        },
      },
    ],
  },
];
