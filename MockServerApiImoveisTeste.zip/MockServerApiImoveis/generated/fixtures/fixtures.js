const { apiImoveis } = require("./imoveis/api-imoveis-fixture");
const { apiCategorias } = require("./categorias/api-categorias-fixture");

module.exports = { apiImoveis, apiCategorias };