exports.apiCategorias = [
    {
        id: 1,
        titulo: "Apartamento"
    },
    {
        id: 2,
        titulo: "Casa"
    },
    {
        id: 3,
        titulo: "Trailler"
    }
];