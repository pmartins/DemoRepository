exports.apiImoveis = [
    {
        id: 1,
        titulo: "Super Luxury Villa",
        descricao: "This villa is an incredible place to spend your holiday, any time of year. ",
        valor: 908587.0
    },
    {
        id: 2,
        titulo: "Victorian House with Garden and Pool",
        descricao: "CLEAN & SAFE: In response to the coronavirus (COVID-19), Algarve Vacation and our respective cleaning services have introduced new procedures.",
        valor: 73267.0
    },
    {
        id: 3,
        titulo: "SPACIOUS VILLA WITH SEA VIEWS, PRIVATE POOL",
        descricao: "CLEAN & SAFE: In response to the coronavirus (COVID-19), Algarve Vacation and our respective cleaning services have introduced new procedures.",
        valor: 254878.0
    },
    {
        id: 4,
        titulo: "Acomodação Luxury em Alto da Cruz",
        descricao: "A volcano rises in the distance and the Atlantic splashes against black volcanic rocks in the dramatic views from this former Pico Island distillery",
        valor: 314666.0
    },
    {
        id: 5,
        titulo: "Villa Ocean Haven by Atlantic Holiday",
        descricao: "VIlla Ocean Haven é uma vila moderna e acolhedora. É composto por quatro quartos, todos eles suites e com guarda roupas.",
        valor: 133733.0
    },
    {
        id: 6,
        titulo: "Acomodação Luxury em Estremoz",
        descricao: "A circular pool tilts toward the sky like an art installation at this gallery-like retreat near Estremoz",
        valor: 613599.0
    }
];