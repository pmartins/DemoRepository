const { funcGetApiCategoriasId } = require("../../functions/categorias/get-api-categorias-id-function");

exports.getApiCategoriasId = (req, res, next, core) => 
{
      var funcReturn = funcGetApiCategoriasId(req.params.id);

      res.status(funcReturn.status);
      res.send(funcReturn.result);
}