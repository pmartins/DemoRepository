const { funcPostApiCategorias } = require("../../functions/categorias/post-api-categorias-function");

exports.postApiCategorias = (req, res, next, core) =>
{
    var funcReturn = funcPostApiCategorias(req.body);

      res.status(funcReturn.status);
      res.send(funcReturn.result);
};