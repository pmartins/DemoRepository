const { postApiCategorias } = require("./post-api-categorias-middleware");
const { getApiCategoriasId } = require("./get-api-categorias-id-middleware");
const { getApiCategoriasTitle } = require("./get-api-categorias-title-middleware");

module.exports = { postApiCategorias, getApiCategoriasId, getApiCategoriasTitle };