const { funcGetApiCategoriasTile } = require("../../functions/categorias/get-api-categorias-title-function");

exports.getApiCategoriasTitle = (req, res, next, core) => 
{
      var funcReturn = funcGetApiCategoriasTile(req.params.title);

      res.status(funcReturn.status);
      res.send(funcReturn.result);
}