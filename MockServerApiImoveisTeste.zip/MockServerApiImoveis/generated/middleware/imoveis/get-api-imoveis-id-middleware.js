const { funcGetApiImoveisId } = require("../../functions/imoveis/get-api-imoveis-id-function");

exports.getApiImoveisId = (req, res, next, core) => 
{
    var funcReturn = funcGetApiImoveisId(req.params.id);

    res.status(funcReturn.status);
    res.send(funcReturn.result);
}