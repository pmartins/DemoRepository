const { postApiImoveis } = require("./post-api-imoveis-middleware");
const { getApiImoveisId } = require("./get-api-imoveis-id-middleware");
const { getApiImoveisName } = require("./get-api-imoveis-name-middleware");

module.exports = { postApiImoveis, getApiImoveisId, getApiImoveisName };