const { funcPostApiImoveis } = require("../../functions/imoveis/post-api-imoveis-function");

exports.postApiImoveis = (req, res, next, core) =>
{
    var funcReturn = funcPostApiImoveis(req.body);

    res.status(funcReturn.status);
    res.send(funcReturn.result);
};