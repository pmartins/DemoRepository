const { funcGetApiImoveisName } = require("../../functions/imoveis/get-api-imoveis-name-function");

exports.getApiImoveisName = (req, res, next, core) => 
{
    var funcReturn = funcGetApiImoveisName(req.params.name);

    res.status(funcReturn.status);
    res.send(funcReturn.result);
}