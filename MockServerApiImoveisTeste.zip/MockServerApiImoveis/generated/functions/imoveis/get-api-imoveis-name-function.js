const { apiImoveis } = require("../../fixtures/imoveis/api-imoveis-fixture");

exports.funcGetApiImoveisName = (name) => 
{
    outPutMessage = {
      status: 200,
      result: {
            id: 1,
            titulo: "Super Luxury Villa",
            descricao: "This villa is an incredible place to spend your holiday, any time of year.",
            valor: 908587.0
      }
    };

    return outPutMessage;
}