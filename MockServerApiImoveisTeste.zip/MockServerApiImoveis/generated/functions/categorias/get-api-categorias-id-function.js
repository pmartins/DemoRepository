const { apiCategorias } = require("../../fixtures/categorias/api-categorias-fixture");

exports.funcGetApiCategoriasId = (id) => 
{
      outPutMessage = {
            status: 200,
            result: {
                  id: 1,
                  titulo: "Apartamento"
            }
      };

      return outPutMessage;
}