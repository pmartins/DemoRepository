1) Executar o ficheiro MockServerApiImoveis\npmInstall.bat uma única vez em cada ambiente instalado.

2) Executar o ficheiro MockServerApiImoveis\run.bat para executar o mock server.
   Esse ficheiro sempre copia os ficheiros da pasta generated e customFiles para as pastas default do mock server

Testes com Postman
Importe a collection que esta na pasta "Postman" para a ferramenta Postman. Essa collection tem as configurações para testes dos endpoints do mock server.